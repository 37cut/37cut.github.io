# Minor settings

### set-default shell
`chsh -s /usr/bin/zsh`

### disable selinux
Edit /etc/selinux/config<br>
Find 'SELINUX=...' then replace 'enforcing' to 'disabled'.

`sudo grubby --update-kernel ALL --args selinux=0`

### disable \`default dirs
Edit $HOME/.config/user-dirs.dirs<br>
Remove the text inside the quotes.

### disable watchdog
Create /etc/modprobe.d/blacklist.conf<br>
Find your wdt via `lsmod`

Then add `blacklist your_module` into the file

### unused services
```shell
sudo systemctl disable avahi-daemon
sudo systemctl disable avahi-daemon.socket
```

### mask services
```shell
sudo systemctl mask sshd
sudo systemctl mask wsdd
sudo systemctl mask NetworkManager-wait-online.service
sudo systemctl mask NetworkManager-dispatcher.service
```

### flameshot
```shell
sudo dnf in qt5-{qtbase,qttools} qt5-qtbase-gui
curl -L https://github.com/flameshot-org/flameshot/releases/download/v0.5.1/flameshot_0.5.1-fedora27-x86_64.rpm > flameshot_0.5.1-fedora27-x86_64.rpm
sudo rpm -i flameshot_0.5.1-fedora27-x86_64.rpm
```

### chromium
Go to ___chrome://flags___

Search ___gemini___ and disable every options include gemini keyword<br>
Search ___optimization guide on device___ and disable it

To prevent chrome download ai models into this folder -> ___$HOME/.config/chromium/OptGuideOnDeviceModel___ <br>
You could make this folder inmutable:<br>
`sudo chattr +i $HOME/.config/chromium/OptGuideOnDeviceModel/`
