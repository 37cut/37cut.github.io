# Display manager / or the login interface

### lightdm -\> xorg-x11-xdm
```shell
sudo dnf rm lightdm
sudo dnf in xorg-x11-xdm
```

### DPI Scale
See /etc/X11/Xresources file

### $HOME/.xsession
```
touch .xsession && echo i3 > .xsession
chmod +x .xsession

systemctl set-default graphical.target
systemctl enable xdm.service
```

by default, xorg-x11-xdm will search for a file called .xsession to determine<br>
which desktop environment to use after user logged in
