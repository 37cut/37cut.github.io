# Packages

### things to add
- alacritty
- alsa-plugins-pulseaudio
- chromium
- dbus-x11
- dunst
- feh
- gimp
- gvfs-archive
- htop
- i3
- ibus ___;remove it first___
- ibus-setup
- ibus-pinyin
- light
- mousepad
- mpv
- NetworkManager-tui
- pcmanfm
- picom
- tlp
- vim-enhanced
- xarchiver
- xsecurelock
- zsh
- zsh-autosuggestions
- zsh-syntax-highlighting

### things to remove
- 7zip ___;replace it with 7zip-standalone___
- abrt
- firefox
- gnome-abrt
- gnome-disk-utility
- imsettings
- nano
- nfs-utils
- pavucontrol
- plymouth
- setroubleshoot
- xorg-x11-drv-{intel,amdgpu,ati,nouveau,openchrome,qxl,vmware}
- xfce4-terminal
- zram-generator
- {amd,nvidia}-gpu-firmware
- {amd-ucode,mt7xxx}-firmware
- {atheros,brcmfmac,libertas,nxpwireless,qcom-wwan,tiwilink}-firmware
- cirrus-audio-firmware
- lightdm ___;beware this___
