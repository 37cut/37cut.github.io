# Packages
import gc
from os import _exit
from PIL import Image, ImageFilter
from signal import signal, SIGINT

# Classes
class FAIHandler:
    def __init__(self, fe, se, em):
        self.f_ext = fe
        self.s_ext = se
        self.e_msg = em

    def ignore_input(self, var): print(f'Ignore input: {var}.')

    def invalid_input(self, var, i):
        print(f'\033[31mInvalid input: {var}.\n{self.e_msg[i]}.\033[0m')
        self.clear_cache()
        _exit(0)

    def f_ext_analysis(self, f):
        if self.f_ext not in self.s_ext:
            self.invalid_input(f, 0)

    def clear_cache(self):
        for i in img_cache: del i
        gc.collect()

class ImageHandler(FAIHandler):
    def __init__(self, img, mod, em):
        self.img = img
        self.mod = mod
        self.e_msg = em
    
    def f_mod_analysis(self):
        cache = self.mod
        if self.mod not in ['RGB', 'RGBA']:
            self.img = self.img.convert('RGBA')
        img_cache.append(self.img)
        return [self.img, cache, self.img.mode]

    def f_res_analysis(self):
        if self.img.size > (65535, 65535):
            self.invalid_input(self.img.size, 1)
        return self.img.size

    def img_info(self, cache):
        print('\n==========< Info >==========')
        if cache not in ['RGB', 'RGBA']:
            print(f'Mode: {cache} -> {self.img.mode}')
        else:
            print(f'Mode: {self.img.mode}')
        print(f'Resolution: {self.img.size[0]}x{self.img.size[1]}px\n')

    def m_resize_img(self, mr, rd):
        if mr != rd and (0, 0) < mr <= (65535, 65535):
            img_cache.append(
                    self.img.resize(mr, resample=Image.BILINEAR))
        else: self.ignore_input(mr)
        return img_cache[1]

    def k_resize_img(self, k, rd):
        cache = None
        x = round(k*rd[0])
        y = round(k*rd[1])
        res = (x, y)
        
        if k!=1 and (0, 0) < res <= (65535, 65535):
            img_cache.append(
                    self.img.resize(res, resample=Image.BILINEAR))
            cache=img_cache[1]
        else:
            self.ignore_input(k)
            cache=img_cache[0]
        return cache
    
    def adjust_image(self, img):
        m = max(*img.size)
        for i in range(0, 32):
            if m < 2000+2000*i:
                k = 1+2*i
                sbuf = img.filter(ImageFilter.MinFilter(k))
                sbuf = sbuf.filter(ImageFilter.MaxFilter(k))
                img_cache.append(sbuf)
                break
        return sbuf

    def save_img(self, fn, text, fe, img):
        if fn in ['/', '\\', '*', ':', '?',
                  '|', '<', '>', '.', '..']:
            self.ignore_input(fn)
            fn = 'output'
            print('File name has changed to \'output\'.')
        fs = fn+text+'.'+fe
        img.save(f'{fs}')
        self.clear_cache()
        print(f'{fs} output successfully.')

img_cache=[]
