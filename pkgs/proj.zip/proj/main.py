import gc
import lib
from os import _exit
from signal import signal, SIGINT
from threading import Thread
from PIL import Image, ImageTk, ImageDraw,\
        ImageEnhance
from tkinter import filedialog, Tk, Frame,\
        Label, Button, Scale, IntVar, DISABLED, HORIZONTAL


# FUNCTION
# ================================================
# Input handler
def handler(sig, frm): _exit(0)

# Execute different action
def exec_crop():
    global t1
    t1 = Thread(target=crop_active,
                args=(new_img_xl.get(),
                      new_img_yt.get(),
                      _img_x-new_img_xr.get(),
                      _img_y-new_img_yb.get()))
    t1.start()
    threads.append(t1)

def exec_restore():
    global t2
    t2 = Thread(target=restore,
                args=(new_img_xl, new_img_yt,
                      new_img_xr, new_img_yb))
    t2.start()
    threads.append(t2)

def exec_draw(x, y, x1, y1, fac):
    global t3
    t3 = Thread(target=draw_section,
                args=(x, y, x1, y1, fac))
    t3.start()
    threads.append(t3)

def exec_refresh():
    global t4
    t4 = Thread(target=refresh_image,
                args=(tk_get_image, tk_show_image, prev_img))
    t4.start()
    threads.append(t4)

def draw_section(x, y, x1, y1, fac):
    rect = [( round(x/fac), round(y/fac) ),
            ( round(x1/fac), round(y1/fac) )]
    cropped_img = ImageDraw.Draw(prev_img)
    cropped_img.rectangle(rect, fill=None, outline="black")

def refresh_image(get, show, prev):
    get = ImageTk.PhotoImage(prev)
    show.configure(image=get)
    show.image = get

def crop_active(x, y, x1, y1):
    global count, old_size, img_cache, prev_img

    new_size = (x, y, x1, y1)
    # If the crop position is correct
    # or the scale value changed, it'll work
    if x < x1 and y < y1:
        if new_size != old_size:
            img_cache = _img.crop(new_size)
            old_size = new_size

            if count != 0:
                count = 0
                # Reset the preview image
                prev_img = _img.resize(
                        (prev_img_x, prev_img_y),
                        resample=Image.BILINEAR)
            count = 1
            
            # Preview image
            exec_draw(*new_size, img_factor)
            exec_refresh()

            # Change the text.
            tk_text_r.configure(text=text_r(*img_cache.size, "(Cropped)"))
            tk_close_button.configure(text="Save 2 images.")
            
            img_cache.show()
    else: fai_handler.invalid_input(new_size, 4)

def restore(x, y, x1, y1):
    global count, old_size, img_cache, prev_img
   
    # Clear various stuff
    img_cache = None
   
    count = 0
    old_size = (0, 0, *_img.size)
    
    for i in x, y, x1, y1: i.set(0)
    
    # Refresh the image
    prev_img = _img.resize(
            (prev_img_x, prev_img_y),
            resample=Image.BILINEAR)
    exec_refresh()

    tk_text_r.configure(text=text_r(*_img.size, ""))
    tk_close_button.configure(text="Close")
    gc.collect()

def close_active():
    for t in threads: t.join()
    root.destroy()
# ================================TheEndOfFunction



# VARIABLE
# ================================================
signal(SIGINT, handler)

VE = ValueError

threads=[]
support_exts=['png', 'jpg', 'bmp', 'gif',
              'tif', 'webp', 'ico', 'psd']
err_msgs = ['File extension not support(or not an image)',
            'Resolution too large(> 65535)',
            'Invalid character',
            'Not a number',
            'Image y\'s length > x\'s length']

print('Please select an image.')
print(f'Support extensions are:\n{support_exts}.')

file = filedialog.askopenfilename()

# File analysis
if file in ['', '.', ()]:
    print("\033[36mNothing input, quitting now.\033[0m")
    _exit(0)
file_short = file.split("/")[-1]
file_ext = ((file_short).split("."))[-1]
fai_handler = lib.FAIHandler(file_ext, support_exts, err_msgs)
fai_handler.f_ext_analysis(file)

# If it's ok, then open the image.
img = Image.open(file)

# Image analysis
i_handler = lib.ImageHandler(img, img.mode, err_msgs)
mod_data = i_handler.f_mod_analysis()
img = mod_data[0]
del mod_data[0]
old_mode=mod_data[0]
res_data=i_handler.f_res_analysis()
# ================================================



# MAIN
# ================================================
i_handler.img_info(old_mode)

# Graph's resolution
print("调整图像大小(最大65535px)")
manual_or_keep=input("手动输入分辨率大小(m)还是保持长宽比(k): ")
if manual_or_keep in ['m', 'M']:
    try: m_image_x = int(input("请输入长: "))
    except VE: fai_handler.invalid_input('x error', 3)
    try: m_image_y = int(input("请输入宽: "))
    except VE: fai_handler.invalid_input('y error', 3)

    m_resolution = (m_image_x, m_image_y)
    img = i_handler.m_resize_img(m_resolution, res_data)
elif manual_or_keep in ['k', 'K']:
    try: k_value=float(input("请输入缩放图片的倍率(... 0.5, 2, 5 ...): "))
    except VE: fai_handler.invalid_input('k error', 3)

    img = i_handler.k_resize_img(k_value, res_data)
else: fai_handler.invalid_input(manual_or_keep, 2)

spec_feature=input("是否调整图像(WIP | y/N): ")
if spec_feature in ['y', 'Y']: img = i_handler.adjust_image(img)

# Graph's sharpness
sharpen_or_not=input("锐化(y/n): ")
if sharpen_or_not in ['y', 'Y']:
    sharpen_tool=ImageEnhance.Sharpness(img)
    
    try: sharpness = float(input("输入锐化因子(默认值2): "))
    except VE: fai_handler.invalid_input('sharpness error', 3)
    if sharpness >= 0:
        _img = sharpen_tool.enhance(sharpness)
    else: fai_handler.ignore_input(sharpness)
else: _img = img
# ================================================



# GUI
# ================================================
root = Tk()
root.title("Image preview")
root.resizable(0, 0)

img_cache = None

count = 0
old_size = (0, 0, *_img.size)

new_img_xl = IntVar()
new_img_xr = IntVar()
new_img_yt = IntVar()
new_img_yb = IntVar()

text_r = lambda x, y, text: f"Resolution{text}: {x}x{y}px"

# Get the size of the sharpened image.
_img_x, _img_y = _img.size 

# The preview image's size should be smaller.
img_factor = max(_img_x/448, _img_y/336)

prev_img_x = round(_img_x/img_factor)
prev_img_y = round(_img_y/img_factor)
prev_img = _img.resize(
        (prev_img_x, prev_img_y), resample=Image.BILINEAR)

# Settings
# Objects
# ================================================
# Image section
tk_main_frame = Frame(root)

# Image info
tk_content_frame = Frame(tk_main_frame)
tk_get_image = ImageTk.PhotoImage(prev_img)
tk_text_image = Label(tk_content_frame, height=1,
                      text="Preview image")
tk_show_image = Label(tk_content_frame, image=tk_get_image,
                      borderwidth=1, relief="solid")
tk_text_r = Label(tk_content_frame, height=1,
                  text=text_r(*_img.size, ""))

# Crop-Y section
tk_cropy_frame = Frame(tk_main_frame)
tk_text_cropyt = Label(tk_cropy_frame, height=1, text="Crop top:")
tk_scale_yt = Scale(tk_cropy_frame, variable=new_img_yt,
                    resolution=1, borderwidth=1,
                    from_=0, to=_img_y-1, width=15,
                    length=prev_img_y, sliderlength=20)
tk_text_cropyb = Label(tk_cropy_frame, height=1, text="Crop bottom:")
tk_scale_yb = Scale(tk_cropy_frame, variable=new_img_yb,
                    resolution=1, borderwidth=1,
                    from_=_img_y-1, to=0, width=15,
                    length=prev_img_y, sliderlength=20)

# Crop-X section
tk_cropx_frame = Frame(tk_content_frame)
tk_text_cropxl = Label(tk_cropx_frame, height=1,
                       text="Crop left:")
tk_scale_xl = Scale(tk_cropx_frame, variable=new_img_xl,
                    resolution=1, borderwidth=1, width=15,
                    from_=0, to=_img_x-1, orient=HORIZONTAL,
                    length=prev_img_x, sliderlength=20)
tk_text_cropxr = Label(tk_cropx_frame, height=1,
                       text="Crop right:")
tk_scale_xr = Scale(tk_cropx_frame, variable=new_img_xr,
                    resolution=1, borderwidth=1, width=15,
                    from_=_img_x-1, to=0, orient=HORIZONTAL,
                    length=prev_img_x, sliderlength=20)

# Button section
tk_button_frame = Frame(tk_cropy_frame)
tk_crop_button = Button(tk_button_frame, width=10, height=1,
                        text="Crop", bg="#6c6", fg="#060",
                        activebackground="#8d8", activeforeground="#060",
                        command=exec_crop)
tk_restore_button = Button(tk_button_frame, width=10, height=1,
                           text="Restore", command=exec_restore)
tk_close_button = Button(tk_button_frame, width=10, height=1,
                         text="Close", command=close_active)
# =================================TheEndOfObjects

# Display
# ================================================
tk_main_frame.pack(anchor="center")

# Crop-Y section(left)
tk_cropy_frame.grid(row=0, column=0, sticky='nw') 
tk_text_cropyb.grid(row=0, column=0)
tk_text_cropyt.grid(row=0, column=1)
tk_scale_yb.grid(row=1, column=0)
tk_scale_yt.grid(row=1, column=1)
tk_text_r.grid(row=2, pady=(2, 0))

# The image(right)
tk_content_frame.grid(row=0, column=1, padx=(0, 15))
tk_text_image.grid(row=0)
tk_show_image.grid(row=1)

# Button section(left)
tk_button_frame.grid(row=2, columnspan=2, pady=(45, 0))
tk_crop_button.grid(row=2)
tk_restore_button.grid(row=3)
tk_close_button.grid(row=4)

# Crop-X section(right, bottom)
tk_cropx_frame.grid(row=3, pady=(0, 15))
tk_text_cropxl.grid(row=3, sticky='w')
tk_scale_xl.grid(row=4)
tk_text_cropxr.grid(row=5, sticky='e')
tk_scale_xr.grid(row=6)

root.mainloop()
# =================================TheEndOfDisplay
# =====================================TheEndOfGUI



# Save the image.
# ================================================
save_or_not = input("Save the image(y/n): ")
if save_or_not in ['y', 'Y']:
    file_name=input("Please input the file name: ")
    i_handler.save_img(file_name, "", file_ext, _img)
    if img_cache != None: i_handler.save_img(file_name, "_cropped", file_ext, img_cache)
else:
    fai_handler.clear_cache()
    print("Canceled.")
_exit(0)
# ================================================
