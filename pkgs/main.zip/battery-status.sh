# CNC --- Charging Notification Count
# DNC --- Discharging Notification Count
CNCCount=0
DNCCount=0

while true
do
	batteryCapacity=`cat /sys/class/power_supply/BAT0/capacity`
	batteryStatus=`cat /sys/class/power_supply/BAT0/status`

	if [ $batteryStatus='Discharging' ]; then
		CNCCount=0
		if [ $batteryCapacity -le 20 ] && [ $DNCCount -lt 1 ]; then
			notify-send -u critical "Battery Low: $batteryCapacity"
			DNCCount+=1
		fi
	# On event charging.
	else
		DNCCount=0
		if [ $batteryCapacity -eq 100 ] && [ $CNCCount -lt 3 ]; then
			notify-send -u normal "Battery Full: $batteryCapacity"
			CNCCount+=1
		fi
	fi
	sleep 60
done
