mkdir -p $HOME/.config/i3
mkdir -p $HOME/.config/dunst
mkdir -p $HOME/.config/alacritty
mv asound.conf hosts i3status.conf vimrc /etc
mv picom.conf /etc/xdg
mv plug.vim /usr/share/vim/vim90/autoload
mv config $HOME/.config/i3
mv alacritty.yml $HOME/.config/alacritty
mv dunstrc $HOME/.config/dunst
mv battery-status.sh $HOME/.config
mv 40-libinput.conf 50-mouse-accel.conf /usr/share/X11/xorg.conf.d
chsh -s /usr/bin/zsh
