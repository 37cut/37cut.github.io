import os
import re
import json
import time
import numpy
import requests
import threading
import contextlib
import utils

def interrupt(excp: str):
    with Semaphore_limit:
        print('> quit with' + ' ' + f'[ {excp} ]')
        os.kill(os.getpid(), 9)

def verify(code: str):
    with Semaphore:
        with_tag = f'sh{code}' if code[0] == '6' else f'sz{code}'
        url = f'https://quote.eastmoney.com/{with_tag}.html'

        try: access = Session.get(url = url)
        except Exception as e: interrupt(e)

        content = access.text

        st = len(re.findall('ST', content)) > 7
        delist = len(re.findall('"bk_name":""', content)) == 1
        not_found = access.status_code == 404

        if not_found: print(f'> {code} [ 404 ]')
        elif st: print(f'> {code} [ ST ]')
        elif delist: print(f'> {code} [ delist ]')
        else:
            information_append = Information.append
            for i in re.finditer('var quotedata = {(.*)};', access.text):
                information_append( json.loads(
                    access.text[i.start():i.end()].split('= ')[-1].replace(';','') ) )
            print(f'> {code} [ valid ]')

def receive(info: dict):
    with Semaphore:
        url = 'https://push2his.eastmoney.com/api/qt/stock/kline/get?'
        parameters = {'fields1': F1,
                      'fields2': F2,
                      'beg': From, 'end': To,
                      'secid': info['quotecode'], 'klt': Type, 'fqt': 1}

        try: access = Session.get(url = url, params = parameters)
        #except requests.exceptions.ConnectionError: interrupt('network interrupt')
        except Exception as e: interrupt(e)

        index_append = Index.append
        data_append = Data.append

        try:
            source = json.loads(access.text)['data']
            index_append(source['code'])

            source = numpy.array([ s.split(',') for s in source['klines'] ]).reshape(-1, 7)
            data_append(source)
        except Exception as e:
            print(e)

def swap(idx: int):
    with Semaphore:
        j = 0
        while Information[j]['code'] != Index[idx]:
            j += 1
        else:
            Information[idx], Information[j] = Information[j], Information[idx]

if __name__ == '__main__':
    with contextlib.suppress(KeyboardInterrupt):
        Code = utils.generate_code(100)
        Semaphore = threading.Semaphore(10)
        Semaphore_limit = threading.Semaphore(1)
        Session = requests.Session()

        Information = list()
        Index = list()
        Data = list()

        F1 = 'f1,f2,f3,f5,f6,f7,f9,f10'
        F2 = 'f51,f52,f53,f54,f55,f56,f59'
        To = time.strftime('%Y%m%d', time.localtime())
        From = str(int(To[:4]) - 8) + To[4:6] + '01'
        Type = 103

        Timer_start = time.time()

        Verify = [ threading.Thread(target = verify,
                                    args = (item,),
                                    daemon = True) for item in Code ]

        [ t.start() for t in Verify ]
        [ t.join() for t in Verify ]

        print(f'> {len(Information)} in {len(Code)} stocks available' + '\n')

        Receive = [ threading.Thread(target = receive,
                                     args = (Information[idx],),
                                     daemon = True) for idx in range(len(Information)) ]

        [ t.start() for t in Receive ]
        [ t.join() for t in Receive ]

        Swap = [ threading.Thread(target = swap,
                                  args = (idx,),
                                  daemon = True) for idx in range(len(Information)) ]

        [ t.start() for t in Swap ]
        [ t.join() for t in Swap ]

        Timer_end = time.time()

        Time_usage = Timer_end - Timer_start

        print(f'> Time usage: {Time_usage:.2f}s;' + ' ' + f'Proceed {len(Information)} stocks')

        for idx in range(len(Information)):
            stock = utils.Stock(Information[idx], Data[idx])
            stock.show()
