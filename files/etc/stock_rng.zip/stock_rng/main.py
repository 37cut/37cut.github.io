import re
import gc
import sys
import json
import time
import numpy
import queue
import platform
import requests
import threading
import contextlib
import subprocess
import utils

def interrupt(excp: str):
    with Semaphore_limit:
        print('> quit with' + ' ' + f'[ {excp} ]')

        os = platform.system()
        if os in ['Linux', 'Darwin']:
            command = 'kill -9 $(ps -C \'python src\' -o pid | grep -v \'PID\')'
        elif os in ['Windows']:
            command = 'taskkill -f -im python.exe'

        gc.collect()
        subprocess.Popen(command, shell = True)

        sys.exit(0)

def verify(code: str):
    with Semaphore:
        with_tag = f'sh{code}' if code[0] == '6' else f'sz{code}'
        with_market = f'1.{code}' if code[0] == '6' else f'0.{code}'

        url = f'https://quote.eastmoney.com/{with_tag}.html'

        try: access = requests.get(url = url)
        except Exception as e: interrupt(e)

        st = len(re.findall('ST', access.text)) > 7
        delist = len(re.findall('"bk_name":""', access.text)) == 1
        not_found = access.status_code == 404

        if not_found: print(f'> {code} [ 404 ]')
        elif st: print(f'> {code} [ st ]')
        elif delist: print(f'> {code} [ delist ]')
        else:
            for i in re.finditer('var quotedata = {(.*)};', access.text):
                Information.append( json.loads(
                    access.text[i.start():i.end()].split('= ')[-1].replace(';','') ) )
            print(f'> {code} [ valid ]')

def receive(info: dict):
    with Semaphore:
        _f1 = 'f1,f2,f3,f5,f6,f7,f9,f10'
        _f2 = 'f51,f52,f53,f54,f55,f56,f59'

        _to = time.strftime('%Y%m%d', time.localtime())
        _from = str(int(_to[:4]) - 8) + _to[4:6] + '01'

        url = 'https://push2his.eastmoney.com/api/qt/stock/kline/get?'
        parameters = {'fields1': _f1, 'fields2': _f2,
                      'beg': _from, 'end': _to,
                      'secid': info['quotecode'], 'klt': 103, 'fqt': 1}

        try: access = requests.get(url = url, params = parameters)
        #except requests.exceptions.ConnectionError: interrupt('network interrupt')
        except Exception as e: interrupt(e)

        source = json.loads(access.text)['data']
        Index.append(source['code'])

        source = numpy.array([ s.split(',') for s in source['klines'] ]).reshape(-1, 7)
        Data.append(source)

def swap(idx: int):
    with Semaphore:
        j = 0
        while Information[j]['code'] != Index[idx]:
            j += 1
        else:
            Information[idx], Information[j] = Information[j], Information[idx]

if __name__ == '__main__':
    with contextlib.suppress(KeyboardInterrupt):
        Code = utils.generate_code(100)
        Semaphore = threading.Semaphore(10)
        Semaphore_limit = threading.Semaphore(1)

        Information = list()
        Index = list()
        Data = list()

        Verify = [ threading.Thread(target = verify,
                                    args = (item,),
                                    daemon = True) for item in Code ]

        for t in Verify: t.start()
        for t in Verify: t.join()

        print(f'> {len(Information)} in {len(Code)} stocks available' + '\n')

        Receive = [ threading.Thread(target = receive,
                                     args = (Information[idx],),
                                     daemon = True) for idx in range(len(Information)) ]

        for t in Receive: t.start()
        for t in Receive: t.join()

        Swap = [ threading.Thread(target = swap,
                                  args = (idx,),
                                  daemon = True) for idx in range(len(Information)) ]

        for t in Swap: t.start()
        for t in Swap: t.join()

        '''
        for idx in range(len(Information)):
            j = 0
            while Information[j]['code'] != Index[idx]:
                j += 1
            else:
                Information[idx], Information[j] = Information[j], Information[idx]
        '''

        #print(Index, Information)

        for idx in range(len(Information)):
            stock = utils.Stock(Information[idx], Data[idx])
            stock.show()

