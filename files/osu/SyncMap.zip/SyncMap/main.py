import os

setID = set()
with open('beatmapsets.txt', 'r') as file:
    [ setID.add(text.strip()) for text in file ]

count = 1
for sid in setID:
    print(sid + f'.osz ({count} of {len(setID)}):')
    os.system(f'curl -L https://txy1.sayobot.cn/beatmaps/download/novideo/{sid}?server=auto > src/{sid}.osz')
    count += 1
