import os
import signal
import urllib.request

def main():
    setID = set()
    with open('beatmapsets.txt', 'r') as file:
        [ setID.add(text.strip()) for text in file ]

    count = 1
    for sid in setID:
        file_name = sid + '.osz'
        file_path = f'src/{file_name}'

        print(file_name + ' ' + f'({count} of {len(setID)})')
        if not os.path.exists(file_path):
            url = f'https://txy1.sayobot.cn/beatmaps/download/novideo/{sid}?server=auto'
            urllib.request.urlretrieve(url, file_path)

        count += 1

signal.signal(signal.SIGINT, lambda *args: os._exit(0))
main()

