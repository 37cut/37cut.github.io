import os

setID = set()
with open('beatmapsets.txt', 'r') as file:
    [ setID.add(text.strip()) for text in file ]

for sid in setID:
    print(sid + '.osk:')
    os.system(f'curl -L https://txy1.sayobot.cn/beatmaps/download/novideo/{sid}?server=auto > src/{sid}.osk')


