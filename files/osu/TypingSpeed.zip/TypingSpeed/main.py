import time
import statistics
import tkinter as tk

class calculate_bpm:
    def __init__(self):
        self.key_times = []

        self.k1 = 'z' if key1.get() == '' else key1.get()
        self.k2 = 'x' if key2.get() == '' else key2.get()

        root.bind('<KeyPress>', self.hold)
        label.config(text='')

    def hold(self, key):
        duration = []

        if key.char in [self.k1, self.k2]:
            single_key_time = time.time()
            self.key_times.append(single_key_time)

            if len(self.key_times) > 1:
                for i in range(len(self.key_times) - 1):
                    difference = self.key_times[i+1] - self.key_times[i]
                    duration.append(difference)

                average = statistics.mean(duration)
                bpm = (60 / average) * 0.25
                label.config(text=f'{bpm:.2f} avg., BPM')

root = tk.Tk()
root.geometry('640x160')
root.resizable(False, False)
root.title('osu! Speed Benchmark')

key1 = tk.StringVar()
key2 = tk.StringVar()

font_family = ('Terminal', 12)

restrict_text_width = lambda text: len(text) <= 1
reg_text = root.register(restrict_text_width)

# default keys
tk.Label(root, text='Select two default keys...', font=font_family).place(x=8, y=0)
tk.Entry(root, width=4, textvariable=key1, font=font_family,
         validate='key', validatecommand=(reg_text, '%P')).place(x=8, y=35)
tk.Entry(root, width=4, textvariable=key2, font=font_family,
         validate='key', validatecommand=(reg_text, '%P')).place(x=70, y=35)

# speed level
tk.Label(root, text='Your typing speed is approximately', font=font_family).place(x=8, y=70)
label = tk.Label(root, text='', font=font_family)
label.place(x=426, y=70)

tk.Button(root, text='Start', font=font_family, command=calculate_bpm).place(x=8, y=107)
tk.Button(root, text='Reset', font=font_family, command=calculate_bpm).place(x=110, y=107)
tk.Button(root, text='Quit', font=font_family, command=root.quit).place(x=550, y=107)

import sys
import signal

signal.signal(signal.SIGINT, lambda *args: sys.exit(0))
root.mainloop()
