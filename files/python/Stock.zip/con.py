import matplotlib.pyplot as mp

class Control:
    def __init__(self, ax: list, period: int):
        self.ax = ax

        self.coord = (-2, period + 1)
        self.__default_c = (-2, period + 1)

        self.move_scale = int(period * 0.05)

    def refresh(self):
        [ self.ax[i].set_xlim(self.coord) for i in range(len(self.ax)) ]
        mp.draw()

    def decrease_view(self):
        if self.coord[0] - self.move_scale < self.__default_c[0] \
        or self.coord[1] + self.move_scale > self.__default_c[1]:
            self.coord = self.__default_c

        else: self.coord = (self.coord[0] - self.move_scale, \
                            self.coord[1] + self.move_scale)

        self.refresh()

    def increase_view(self):
        if self.coord[0] + self.move_scale > self.coord[1]:
            self.coord = self.__default_c

        else: self.coord = (self.coord[0] + self.move_scale, \
                            self.coord[1] - self.move_scale)

        self.refresh()

    def to_left(self):
        if not self.coord[0] - self.move_scale < self.__default_c[0]:
            self.coord = (self.coord[0] - self.move_scale, \
                          self.coord[1] - self.move_scale)

        self.refresh()

    def to_right(self):
        if not self.coord[1] + self.move_scale > self.__default_c[1]:
            self.coord = (self.coord[0] + self.move_scale, \
                          self.coord[1] + self.move_scale)

        self.refresh()

    def adjust_graph(self, match: str):
        method = {
            'up':       self.decrease_view,
            'down':     self.increase_view,
            'left':     self.to_left,
            'right':    self.to_right}
        return method.get(match, lambda: '')()

    def mouse(self, event):
        if event: self.adjust_graph(event.button)

    def keyboard(self, event):
        if event: self.adjust_graph(event.key)
