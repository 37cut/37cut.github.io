import pandas
import requests
import threading

import matplotlib
matplotlib.use('TkAgg')

import mplcursors
import matplotlib.pyplot as mp
import matplotlib.ticker as mt
import matplotlib.font_manager as mf

import os, re, time, json, random, contextlib

import con

print('> Stock RNG v2')
print('> This program requires a network connection to proceed')
print('> Do not close this program while processing data' + '\n')

class Generator:
    def __init__(self, size: int):
        self.size = size

        self.cset = set()
        self.info = list()
        self.kline = list()

        # Do not change the data inside the list
        self.head = ['day', 'open', 'close', 'high', 'low', 'volume']

        self._t = list()

    def interrupt(self, msg: str):
        print('> Quit with an exception: ', msg)
        os.kill(os.getpid(), 9)

    def code(self):
        locate_code = ['600', '601', '603',
                       '300', '301', '000',
                       '001', '002', '003'][random.randint(0, 8)]

        lc = 'sz' if locate_code[0] != 6 else 'sh'

        while len(self.cset) != self.size:
            seed = str(random.randint(100, 65535) * random.randint(100, 65535))
            x = random.randint(0, len(seed) - 4)
            y = x + 3

            self.cset.add(lc + locate_code + seed[x:y])

        self.do_work(self.verify, self.cset)

    def verify(self, item: str):
        working = True

        while working:
            url = 'https://quote.eastmoney.com/' + item + '.html'

            try: access = requests.get(url = url, timeout = 60)
            except Exception as e: self.interrupt(e)

            if access.status_code == 200 \
            or item not in self.cset:
                working = False
            else:
                self.cset.remove(item)
                self.code()

    def getinfo(self, item: str):
        working = True

        buffer = ''
        buff_append = self.info.append

        while working:
            url = 'https://quote.eastmoney.com/' + item + '.html'

            try: access = requests.get(url = url, timeout = 60)
            except Exception as e: self.interrupt(e)

            content = access.text
            matches = re.finditer('var quotedata = {(.*)};', content)

            for match in matches:
                buffer = json.loads( content[match.start():match.end()] \
                             .split('= ')[-1].replace(';','') )

                buff_append(buffer)

            working = False

    def getkline(self, item: str):
        working = True

        buffer = ''
        buff_insert = self.kline.insert

        scale = 7200
        datalen = 12 * 8

        while working:
            url = 'http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?'
            parameters = {
                'symbol': item,
                'scale': scale,
                'datalen': datalen,
                'ma': 'no'
            }

            try: access = requests.get(url = url, params = parameters, timeout = 60)
            except Exception as e: self.interrupt(e)

            buffer = json.loads(access.text)

            df = pandas.DataFrame(buffer, columns = self.head)

            df[ self.head[0] ] = df[ self.head[0] ].astype(str)
            df[ self.head[5] ] = df[ self.head[5] ].astype(int)
            df[ self.head[1:5] ] = df[ self.head[1:5] ].astype(float)

            [
                buff_insert(i, df) \
                if self.info[i]['code'] == item[2:] else None \
                for i in range(len(self.info))
            ] \
            if buffer != 'null' else self.info.remove(item)

            working = False

    def plot(self, item_info: dict, item_kline: list):
        code      = item_info['code']
        name      = item_info['name']
        bk_name   = item_info['bk_name'] if item_info['bk_name'] != '' else 'delisted'

        date      = item_kline[ self.head[0] ].tolist()
        open      = item_kline[ self.head[1] ].tolist()
        close     = item_kline[ self.head[2] ].tolist()
        high      = item_kline[ self.head[3] ].tolist()
        low       = item_kline[ self.head[4] ].tolist()
        volume    = item_kline[ self.head[5] ].tolist()

        period = len(date)

        x_major_locator = mt.MultipleLocator( int( period * 0.3 ) )

        font = mf.FontProperties(fname = os.path.dirname(__file__) \
                                       + '/font/wqy-font.ttf', size = 16)

        title_color = '#009900' if close[0] > close[-1] else '#990000'


        # layout
        fig, ax = mp.subplots( nrows = 2, ncols = 1,
                               constrained_layout = True,
                               gridspec_kw = dict(height_ratios = [7, 3]) )

        fig.suptitle(f'{code}, {name} [ {bk_name} ]', fontproperties = font)

        fig.set_constrained_layout_pads(w_pad=0.5, wspace=0.1)


        # event connect
        control = con.Control(ax, period)

        fig.canvas.mpl_connect('scroll_event', control.mouse)
        fig.canvas.mpl_connect('key_press_event', control.keyboard)


        # plot kline
        ax[0].set_title(label = f'Last updated price: {close[-1]}' \
                              + '   ', color = title_color, fontproperties = font)

        ax[0].xaxis.set_major_locator(x_major_locator)
        ax[0].set_xlim(-2, period + 1)

        ax[0].plot(date, open, label = 'Open Price')
        ax[0].plot(date, close, label = 'Close Price')
        ax[0].plot(date, high, label = 'Highest Price',
                   color = 'r', marker = '.', linestyle = 'dotted')
        ax[0].plot(date, low, label = 'Lowest Price',
                   color = 'g', marker = '.', linestyle = 'dotted')
        ax[0].legend(loc = 'best')


        # plot volume
        ax[1].set_title(f'Last updated volume: {volume[-1]}' + '   ', fontproperties = font)

        ax[1].xaxis.set_major_locator(x_major_locator)
        ax[1].set_xlim(-2, period + 1)

        ax[1].bar(date, volume, label = 'Volume')
        ax[1].legend(loc = 'best')

        mplcursors.cursor()

        mp.show()
        mp.close()


    def run(self) -> str:
        with contextlib.suppress(KeyboardInterrupt):
            _timer = time.time()

            self.code()

            self.do_work(self.getinfo, self.cset)
            self.do_work(self.getkline, self.cset)

            print('Time usage: ', time.time() - _timer)

            [ self.plot(self.info[i], self.kline[i]) for i in range(len(self.info)) ]

        return "END"

    def do_work(self, func, item):
        self._t = [ threading.Thread(target = func,
                                     args = (it,),
                                     daemon = True) for it in item ]

        [ t.start() for t in self._t ] \
            if not any(t.is_alive() for t in self._t) else None

        [ t.join() for t in self._t ]
