import lib

generator = lib.Generator(10)
g = generator.run()
