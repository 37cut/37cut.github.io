import modules.lib as lib

generator = lib.Generator(10)
g = generator.run()
