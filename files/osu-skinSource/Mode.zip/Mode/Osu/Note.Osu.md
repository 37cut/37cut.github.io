# Circles -> approachcircle
- Canva: 272x272
- Color: #ffffff

# Circles -> (hit,sliderstart}cirle
- Canva: 272x272
- Color: #ffffff and #000000
- Feather: 3px
- Drop shadow:
	- blur radius: 6
	- grow radius: 3
	- opacity: 2(max)

# Circles -> {hit,sliderstart}cirleoverlay
- Canva: 272x272
- Color: #ffffff
- Feather: 2px
- Drop shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)

# Circles -> sliderb
- Canva: 272x272
- Color: #000000
- Feather: 3px
- Drop shadow:
    - blur radius: 6
    - grow radius: 3
    - opacity: 2(max)

# Circles -> reversearrow
- Canva: 272x272
- Color: #ffffff
- Drop shadow:
	- blur radius: 2
	- grow radius: 1
	- opacity: 2(max)

# Default-numbers -> default-{0,1,2,3,4,5,6,7,8,9}
- Canva: 70x104
- Font: "Cute Aurora"-116px
- Drop shadow:
	- color: #000000
	- blur radius: 1
	- grow radius: 1
	- opacity: 1

# Hit-numbers -> hit{0,50,100,100k}-0
- Canva: 160x96
- The cross symbol: ×
- The 100k symbol: 喝
- Font: "Sans-serif Bold"-63px, "Louis George Cafe Bold"-64px(50,100), "Sans-serif Bold"-64px
- Color: #ff3333, #ffeecc, #eeffcc(100,100k)
- Drop shadow:
    - color: #ff3300, #ffcc99, #ccff99(100,100k)
    - blur radius: 6
    - grow radius: 0
    - opacity: 0.5

# Spinner -> spinner-circle
- Canva: 512x512

# Spinner -> spinner-rpm
- Canva: 176x80
- Color: #eeffcc
- Font: Constantia-64px
- Drop shadow:
	- color: #eeffcc
	- blur radius: 4
	- grow radius: 0
	- opacity: 1
