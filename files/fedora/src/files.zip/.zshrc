source /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh
source /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh

alias ls="ls --color"
PROMPT="[%F{#ccffff}%~%f][%F{#ccffff}%#%f] "
RPROMPT="[%(?.%F{#ccffff}Normal%f.%F{#cc0000}Failed%f)]"

setopt CORRECT
setopt TRANSIENT_RPROMPT
