# approachcircle
- Resolution: 256x256
- Circle Size: 252x252
- Color: #ffffff


# cursor
- Resolution: 128x128
- Color: #ffffff, #000000 and #ffff80
- 'Blur' Layer:
	- Same as cursortrail but 5.0 opacity


# cursor-smoke
- Resolution: 64x64
- Color: #ffffff


# cursortrail
- Resolution: 128x128
- Color: #ffffcc
- Focus Blur:
	- Gaussian Blur
	- 5px
	- High quality

# hitcirle
- Resolution: 256x256
- Feather: 3px
- Drop Shadow:
	- blur radius: 6
	- grow radius: 3
	- opacity: 2(max)
- Color: #ffffff and #000000


# hitcirleoverlay & sliderstartcircleoverlay
- Feather: 2px
- Resolution: 256x256
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)


# pause-<i>objects</i>
- Resolution: 768x128
- Font: Cantarell
- Font size: 96px(Note: pause-retry.xcf with 100px font size)
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)


# ranking-<i>objects</i>
- Resolution:
	- ...accuracy: 454x128
	- ...maxcombo: 320x128
- Font: Cantarell(...perfect with LT Binary Neue)
- Font size: 100px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)


# selection-tab
- Resolution: 236x44
- Color: #66eeee


# sliderb
- Resolution: 256x256
- Drop Shadow:
    - blur radius: 6
    - grow radius: 3
    - opacity: 2(max)


# spinner-rpm
- Resolution: 176x96
- Font size: 64


# play-skip
- Resolution: 768x384
- Font: Cantarell
- Font size: 299px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)
