# Content
- Audio: Store all audio files
- Interface: As the name
- Mania, Osu: Widgets
- Transparent: Useless widgets



___***Osu***___

# Osu::approachcircle
- Resolution: 256x256
- Circle Size: 256x256(18px)
- Color: #ffffff

# Osu::hitcirle
- Resolution: 256x256
- Circle Size: 192x192
- Color: #ffffff and #000000
- Feather: 3px
- Drop Shadow:
	- blur radius: 6
	- grow radius: 3
	- opacity: 2(max)

# Osu::{hit,sliderstart}cirleoverlay
- Resolution: 256x256
- Circle Size: 224x224
- Color: #ffffff
- Feather: 2px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)

# Osu::sliderb
- Resolution: 256x256
- Circle Size: 192x192
- Color: #000000
- Drop Shadow:
    - blur radius: 6
    - grow radius: 3
    - opacity: 2(max)

# Osu::reversearrow
- Resolution: 256x256
- Circle Size: 176x176
- Color: #ffffff
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)

# Osu::Default::default-{0,1,2,3,4,5,6,7,8,9}
- Resolution: 70x104
- Font: Cute Aurora
- Font size: 116
- Drop shadow:
	- color: #000000
	- blur radius: 1
	- grow radius: 1
	- opacity: 1



___***Interface***___

# Interface::selection-tab
- Resolution: 236x44
- Size: 194x36
- Position: Right Bottom
- Color: #ffffff

# Interface::spinner-rpm
- Resolution: 176x96
- Font: LT Binary Neue
- Font size: 64
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)

# Interface::play-skip
- Resolution: 768x384
- Font: Cantarell
- Font size: 299px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)

# Interface::menu-button-background
- Resolution: 1412x212
- 'Any' Color: 000033
- 'Layer' Feather: 3px

# Interface::Cursor::cursor
- Resolution: 128x128
- 'Paint' Layer:
	- Color: #000000
- 'Cursor' Layer:
	- Color: #ffffff, #ffff80
	- Circle Size: 64x64
- 'Blur' Layer:
	- Same as cursortrail
	- 5.0 opacity
	- Purpose: to smooth the edges

# Interface::Cursor::cursortrail
- Resolution: 128x128
- Color: #ffffcc
- Focus Blur:
	- Gaussian Blur
	- 5px
	- High quality

# Interface::Cursor::cursor-smoke
- Resolution: 64x64
- Color: #ffffff

# Interface::Pause::pause-{back,continue,replay,retry}
- Resolution: 768x128
- Font: Cantarell
- Font size: 96px(Note: pause-retry.xcf with 100px font size)
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)

# Interface::Ranking::ranking-{accuracy,maxcombo,perfect}
- Resolution:
	- ...accuracy: 454x128
	- ...maxcombo: 320x128
- Font: LT Binary Neue(ranking-perfect has no font)
- Font size: 100px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)

# Interface::Ranking::ranking-{X,S,A,B,C,D,SH,XH}-small
- Font: Source Code Pro Light Italic
- Font size: 64px
- color: #ffcc66, #ffcc66, #ccff66, #66ccff, #cc66ff, #ff6666, #cccccc, #cccccc
- Drop Shadow:
	- color: #ff9966, #ff9966, #99ff66, #6699ff, #9966ff, #ff3333, #999999, #999999
	- blur radius: 2
	- grow radius: 0
	- opacity: 1