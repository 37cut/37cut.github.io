# Editor
- Audio Edit: audacity
- Graphic Edit: gimp

# Content
- Audio: Store all audio files
- Interface: As the name
- Mania, Osu: Widgets
- Transparent: Useless widgets to hide

___***Osu***___

# Osu::approachcircle
- Resolution: 272x272
- Circle Size: 272x272(18px)
- Color: #ffffff

# Osu::hitcirle
- Resolution: 256x256
- Circle Size: 192x192
- Color: #ffffff and #000000
- Feather: 3px
- Drop Shadow:
	- blur radius: 6
	- grow radius: 3
	- opacity: 2(max)

# Osu::{hit,sliderstart}cirleoverlay
- Resolution: 256x256
- Circle Size: 224x224
- Color: #ffffff
- Feather: 2px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)

# Osu::sliderb
- Resolution: 256x256
- Circle Size: 192x192
- Color: #000000
- Feather: 3px
- Drop Shadow:
    - blur radius: 6
    - grow radius: 3
    - opacity: 2(max)

# Osu::reversearrow
- Resolution: 256x256
- Circle Size: 176x176
- Color: #ffffff
- Feather: 3px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)

# Osu::Default::default-{0,1,2,3,4,5,6,7,8,9}
- Resolution: 70x104
- Font: Cute Aurora
- Font size: 116
- Drop shadow:
	- color: #000000
	- blur radius: 1
	- grow radius: 1
	- opacity: 1

___***Interface***___

# Interface::selection-tab
- Resolution: 236x44
- Size: 194x36
- Position: Right Bottom
- Color: #ffffff

# Interface::spinner-rpm
- Resolution: 176x96
- Font: Constantia
- Font size: 64
- Drop Shadow:
	- blur radius: 4
	- grow radius: 0
	- opacity: 1

# Interface::play-skip
- Resolution: 928x460
- Font: Candara
- Font size: 340px
- 'Character.xcf' Layer:
	- Drop Shadow:
		- x,y: 5,5
		- blur radius: 4
		- grow radius: 0
		- opacity: 0.25
- 'Skip' Layer:
	- Color: #eeffcc
	Long Shadow:
		- style: fading(fixed length)
		- length: 32
		- color: #bbcc99
		
# Interface::menu-button-background
- Resolution: 1412x212
- 'Any' Color: #000033
- 'Layer' Feather: 3px

# Interface::Cursor::cursor
- Resolution: 128x128
- 'Paint' Layer:
	- Color: #000000
- 'Padding' Layer:
	- Color: #ffffff 
- 'Cursor' Layer:
	- Color: #ffff80
	- Circle Size: 80x80
- 'Blur' Layer:
	- Focus Blur(Gaussian Blur)
	- 3px
	- High quality
	
# Interface::Cursor::cursortrail
- Resolution: 128x128
- Color: #ffffcc
- Focus Blur(Gaussian Blur):
	- 3px
	- High quality

# Interface::Cursor::cursor-smoke
- Resolution: 16x16
- Feather: 4px
- Color: #eeffcc

# Interface::Pause::pause-{back,continue,replay,retry}
- Resolution: 768x128
- Font: Constantia
- Font size: 80px
- Color: #eeffcc
- Drop Shadow:
	- color: #eeffcc
	- blur radius: 4
	- grow radius: 0
	- opacity: 1

# Interface::Ranking::ranking-graph
- Resolution: 632x320
- Color: #eeffcc
- Drop Shadow:
	- color: #bbcc99
	- blur radius: 4
	- grow radius: 0
	- opacity: 1

# Interface::Ranking::ranking-panel
- Resolution: 1920x1332
- Color: #eeffcc, #111111, #000000
- 'Panel::Character.xcf' Layer:
	- Position: Right Bottom
	- Drop Shadow:
		- x,y: 5,5
		- blur radius: 4
		- grow radius: 0
		- opacity: 0.25
- 'Panel::PanelWidget::Score' Layer:
	- Font: Candara
	- Font size: 96px
	- Color: #ffffff
	- Drop Shadow:
		- x,y: 10,10
		- blur radius: 8
		- grow radius: 0
		- opacity: 1

# Interface::Ranking::ranking-{accuracy,maxcombo}
- Resolution:
	- ...accuracy: 448x128
	- ...maxcombo: 320x128
- Font: Mingzat
- Font size: 80px
- Color: #f3ffcc
- Drop Shadow:
	- x,y: 5,5
	- blur radius: 4
	- grow radius: 0
	- opacity: 1

# Interface::Ranking::ranking-title
- Resolution: 620x272
- Font: Candara
- Font size: 172px
- Color: #eeffcc
- Drop Shadow:
	- color: #bbcc99
	- blur radius: 2
	- grow radius: 0
	- opacity: 2

# Interface::Ranking::ranking-{X,S,A,B,C,D,SH,XH}-small
- Resolution: 68x80
- Font: Source Code Pro Light Italic
- Font size: 64px
- Color: #ffcc66, #ffcc66, #ccff66, #66ccff, #cc66ff, #ff6666, #cccccc, #cccccc
- Drop Shadow:
	- color: #ff9966, #ff9966, #99ff66, #6699ff, #9966ff, #ff3333, #999999, #999999
	- blur radius: 2
	- grow radius: 0
	- opacity: 1

# Interface::Ranking::ranking-{X,S,A,B,C,D,SH,XH}
- Resolution: 768x768
- Font: ft anima
- Font size: 768px
- Color: #f3ffcc, #eeffcc, #eeffcc, #bbcc99, #bbcc99, #bbcc99, #eeffdd, #f3ffdd
- Drop Shadow(For ranking-{B,C,D}):
	- color: #999999
	- blur radius: 8
	- grow radius: 0
	- opacity: 0.5
- Drop Shadow(except ranking-{B,C,D}):
	- color: same as Color
	- blur radius: 8
	- grow radius: 0
	- opacity: 0.5

# Interface::Score::score-{0,1,2,3,4,5,6,7,8,9}
- Resolution: 48x80
- Font: Philosopher
- Font size: 80px
- Drop Shadow:
	- color: black once, white once
	- blur radius: 1
	- grow radius: 0
	- opacity: 1

# Interface::Score::score-{comma,dot}
- Resolution: 24x80
- Font: Cute Aurora
- Font size: 64px
- Drop Shadow:
	- color: black once, white once
	- blur radius: 1
	- grow radius: 0
	- opacity: 1

# Interface::Score::score-{percent,x}
- Resolution: 24x80
- Font: Cute Aurora
- Font size: 32px
- Drop Shadow:
	- color: black once, white once
	- blur radius: 1
	- grow radius: 0
	- opacity: 1