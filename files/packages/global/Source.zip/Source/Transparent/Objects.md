# Transparent Objects:
- followpoint-{0,1,8,9}.png

- hit300-0.png
- hit300g-0.png
- hit300k-0.png

- inputoverlay-key.png

- lighting.png

- scorebar-bg.png

- sliderendcircle.png
- sliderendcircleoverlay.png
- sliderfollowcircle.png

- spinner-approachcircle.png
- spinner-background.png
- spinner-metre.png

- star2.png