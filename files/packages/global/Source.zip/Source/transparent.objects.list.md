# Transparent Objects:
- followpoint-{0,1,8,9}.png

- hit300-0.png
- hit300g-0.png
- hit300k-0.png

- inputoverlay-key.png

- lighting.png
- lightingL.png
- lightingN.png

- scorebar-bg.png

- sliderendcircle.png
- sliderendcircleoverlay.png
- sliderfollowcircle.png

- spinner-approachcircle.png
- spinner-background.png
- spinner-glow.png
- spinner-metre.png
- spinner-rpm.png
- spinner-{bottom,middle,middle2,top}.png

- star2.png