Avoid transparent pixels around any objects.(Influence the gameplay)
To prevent that, use this method
Create a layer contains "0.2% opacity white pixels(you create by yourself)" around the edge of the image.

Feather: If I didn't say, 3px as default.

# approachcircle
- Resolution: 256x256
- Edge of the circle: no feather(<b>NOT 0px feather</b>)
- Inside Edge of the circle: Feather: 7px
- Color: #ffffff


# cursor
- Resolution: 96x96
- Color: #ffffff, #000000 and #339999
- Note: 'Cursor' layer duplicate for 1 time


# cursor-smoke
- Resolution: 60x60
- Color: #ffffff


# cursortrail
- Resolution: 96x96
- Color: #ffffcc
- Feather: 7px
- Note: duplicate layer for 4 times.


# hitcirle
- Resolution: 256x256
- Drop Shadow:
	- blur radius: 6
	- grow radius: 3
	- opacity: 2(max)
- Color: #ffffff and #000000


# hitcirleoverlay & sliderstartcircleoverlay
- Resolution: 256x256
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)


# pause-<i>objects</i>
- Resolution: 768x128
- Font: Cantarell
- Font size: 96px(Note: pause-retry.xcf with 100px font size)
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)


# ranking-<i>objects</i>
- Resolution:
	- ...accuracy: 454x128
	- ...maxcombo: 320x128
- Font: Cantarell(...perfect with LT Binary Neue)
- Font size: 100px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)


# selection-tab
- Resolution: 236x44
- Color: #66eeee


# sliderb
- Resolution: 256x256
- Drop Shadow:
    - blur radius: 6
    - grow radius: 3
    - opacity: 2(max)


# spinner-rpm
- Resolution: 176x96
- Font size: 64


# play-skip
- Resolution: 768x384
- Font: Cantarell
- Font size: 299px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)
