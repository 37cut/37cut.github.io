Avoid transparent pixels around any objects.(Influence the gameplay)
To prevent that, use FakeObject layer,
which is "0.2% opacity white pixels(you create by yourself)" around the edge of the image.
But dont use it on:
- approachcircle
- hitcircle
- hitcircleoverlay

const stands for constance.
Here const means avoid changing these objects' resolution to the others.(Influence the gameplay)


1. approachcircle
- Resolution: 256x256(const)
- Edge of the circle: no feather(<b>NOT 0px feather</b>)
- Inside Edge of the circle: 7px feather



2. hitcirle
- Resolution: 256x256(const)
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)



3. hitcirleoverlay
- Resolution: 256x256(const)
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)



4. pause-<i>objects</i>
- Resolution: 768x128
- Font: Cantarell
- Font size: 96px(Note: pause-retry.xcf with 100px font size)
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)



5. ranking-<i>objects</i>
- Resolution:
	- ...accuracy: 454x128
	- ...maxcombo: 320x128
- Font: Cantarell(...perfect with LT Binary Neue)
- Font size: 100px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)



6. play-skip
- Resolution: 768x384
- Font: Cantarell
- Font size: 299px
- Drop Shadow:
	- blur radius: 2
	- grow radius: 3
	- opacity: 2(max)