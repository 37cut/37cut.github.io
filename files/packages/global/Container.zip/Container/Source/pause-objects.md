1. Resolution: 768x128
2. Font size: 96px(Note: pause-retry.xcf with 100px font size)
3. Drop Shadow:
- blur radius: 2
- grow radius: 3
- opacity: 2(max)