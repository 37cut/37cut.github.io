# Transparent Objects:
- cursortrail.png

- followpoint-{0,1,8,9}.png

- hit300-0.png
- hit300g-0.png
- hit300k-0.png

- inputoverlay-background.png
- inputoverlay-key.png

- lighting.png
- lightingL.png
- lightingN.png

- mania-hit300.png
- mania-key1.png
- mania-key1D.png
- mania-key2.png
- mania-key2D.png
- mania-keyS.png
- mania-keySD.png
- mania-stage-{left,right}.png
- mania-warningarrow.png

- scorebar-bg.png

- sliderendcircle.png
- sliderendcircleoverlay.png
- sliderfollowcircle.png

- spinner-approachcircle.png
- spinner-background.png
- spinner-glow.png
- spinner-metre.png
- spinner-rpm.png
- spinner-{bottom,middle,middle2,top}.png

- star2.png