# Transparent Objects:
- followpoint-{0,1,8,9}@2x.png

- hit300-0@2x.png
- hit300g-0@2x.png
- hit300k-0@2x.png

- inputoverlay-key@2x.png
- inputoverlay-background@2x.png

- lighting@2x.png

- scorebar-bg@2x.png

- sliderendcircle@2x.png
- sliderendcircleoverlay@2x.png
- sliderfollowcircle@2x.png

- spinner-approachcircle@2x.png
- spinner-background@2x.png
- spinner-metre@2x.png

- star2@2x.png